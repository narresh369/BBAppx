export class OrdersxModel {
    $key?: string;
    billno:string;
    createdttm:string;
    name:string;
    image:string;
    imgFlg:string;
    rate:number;
    oldrate:number;
    qty:number;
    description:string;
    amtx:number;
    qtyx:number;
}

