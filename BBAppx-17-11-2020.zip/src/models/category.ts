export default class Category {
    key: string;
    title: string;
    cover: string;
    imgFlg = false;
  }