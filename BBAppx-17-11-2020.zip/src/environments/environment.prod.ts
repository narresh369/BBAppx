/* export const environment = {
  production: true 
}; */
export const environment = {
  production: true,
  api: `https://master.tus.io/files/`,
  firebaseConfig: {
    apiKey: "AIzaSyCIpv6hmYDjBBw9fdmUHAHegg2mPEksHII",
    authDomain: "bbapp-a4a47.firebaseapp.com",
    databaseURL: "https://bbapp-a4a47.firebaseio.com",
    projectId: "bbapp-a4a47",
    storageBucket: "bbapp-a4a47.appspot.com",
    messagingSenderId: "915106264790",
    appId: "1:915106264790:web:dd4def8e157fc5af547b77",
    measurementId: "G-6J8P7CKLCF"
  }
};